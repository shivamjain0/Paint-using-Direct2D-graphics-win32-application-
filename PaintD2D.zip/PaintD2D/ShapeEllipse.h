#pragma once
#include "Shapes.h"

//class ShapeEllipse :
//	public Shapes
//{
//
//	D2D1_ELLIPSE curEllipse;
//
//	void OnDrawShape(ID2D1HwndRenderTarget *pRenderTarget, ID2D1SolidColorBrush *pBrush, ID2D1Factory* pFactory = nullptr);
//	void FillShape(ID2D1HwndRenderTarget *pRenderTarget, ID2D1SolidColorBrush *pBrush, ID2D1Factory* pFactory);
//	void SetColor(ID2D1SolidColorBrush* curPBrush_);
//};

